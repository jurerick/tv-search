import { TvSearchApp } from './TvSearchApp.js';

customElements.define('tv-search-app', TvSearchApp);
