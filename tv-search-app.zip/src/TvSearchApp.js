import { LitElement, html, css } from 'lit';
import TVMazeClient from "./TVMazeClient";

const logo = new URL('../assets/open-wc-logo.svg', import.meta.url).href;

export class TvSearchApp extends LitElement {
  static get properties() {
    return {
      title: { type: String },
      shows: []
    };
  }

  static get styles() {
    return css`
      :host {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        font-size: calc(10px + .5vmin);
        color: #1a2b42;
        max-width: 960px;
        margin: 0 auto;
        text-align: center;
        background-color: var(--tv-search-app-background-color);
      }

      main {
        flex-grow: 1;
        margin: 5em;
      }

      .app-footer {
        font-size: calc(12px + 0.5vmin);
        align-items: center;
      }

      .app-footer a {
        margin-left: 5px;
      }

      .app-tv-shows {
        display: flex;
        flex-wrap: wrap;
      }

      .app-tv-shows > .show-item {
        width: 45%;
        margin: 1em;
        box-sizing: border-box;
        border: 1px solid #333;
        display: flex;
      }

      .app-tv-shows > .show-item > div {
        width: 45%;
      }
      .app-tv-shows > .show-item .show-image {
        width: 100%;
      }
    `;
  }

  constructor() {
    super();
    this.title = 'My app';
    this.shows = [];
  }

  async search(e) {
    if(e.keyCode === 13 && e.key === "Enter") {
      this.shows = await TVMazeClient.searchShows(e.currentTarget.value);
    }
  }

  render() {

    const parser = new DOMParser();

    const showsElement = (this.shows.length > 0) ? this.shows.map(result => {

      const htmlDesc = parser.parseFromString(result.show.summary, 'text/html');

      return html`
        <div class="show-item">
          <div class="left-col">
            <img class="show-image" src="${result.show.image.medium}" />
          </div>
          <div>
            <div class="show-title">${result.show.name}</div>
            <div class="show-rating">${result.show.rating.average}</div>
            <div class="show-description">
              ${htmlDesc.getElementsByTagName("p").item(0).textContent.slice(0, 200)}
            </div>
          </div>
        </div>
      `;
    }) : [];


    return html`
      <main>
        <input type="text" @keypress="${this.search}" name="search" placeholder="Search TV shows"  />

        <div class="app-tv-shows">
          ${showsElement}
        </div>
      </main>

      <p class="app-footer">
        🚽 Made with love by
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="https://github.com/open-wc"
          >open-wc</a
        >.
      </p>
    `;
  }
}
